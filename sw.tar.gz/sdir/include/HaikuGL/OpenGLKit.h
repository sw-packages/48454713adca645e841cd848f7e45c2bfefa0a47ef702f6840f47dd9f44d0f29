/*
 * Master include file for the Haiku OpenGL Kit.
 */

#include <GL/gl.h>
#include <GLView.h>

// Projects needing GL/glu.h and GL/glut.h should now
// include these headers independently as glu and glut
// are no longer core parts of mesa
